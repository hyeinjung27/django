from django.apps import AppConfig


class TodolistappConfig(AppConfig):
    name = 'todolistapp'
